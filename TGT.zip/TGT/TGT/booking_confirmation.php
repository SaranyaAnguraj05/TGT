<?php
session_start();

error_reporting(0);
include('includes/config.php');

?>

<?php			

// Get the booking details from the session variables
$booking_id = $_SESSION['booking_id'];
$vehicle_id = $_SESSION['vehicle_id'];
$vehicle_number = $_SESSION['vehicle_number'];
$vehicle_model = $_SESSION['vehicle_model'];
$km_travelled = $_SESSION['km_travelled'];
$cost_per_km = $_SESSION['cost_per_km'];
$total_cost = $_SESSION['total_cost'];
$email = $_SESSION['email'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>Booking Confirmation</title>
<style>
h1 {
  text-align: center;
  font-size: 2.5em;
}

p {
  font-size: 1.2em;
  margin-top: 20px;
  margin-bottom: 10px;
}

table {
  width: 80%;
  margin: auto;
  border-collapse: collapse;
  border: 2px solid black;
  font-size: 1.1em;
  margin-top: 30px;
}

table td {
  border: 1px solid black;
  padding: 10px;
}

table tr:nth-child(even) {
  background-color: #f2f2f2;
}

a {
  display: inline-block;
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  font-size: 1.2em;
  margin-top: 30px;
}

a:hover {
  background-color: #3e8e41;
}






</style>
</head>
<body>
	<h1>Booking Confirmation</h1>
	
<center><p>Thank you for booking with us. Your booking details are:</p></center>
	<table>
		<tr>
			<td>Booking ID:</td>
			<td><?php echo $booking_id; ?></td>
		</tr>
		<tr>
			<td>Vehicle Number:</td>
			<td><?php echo $vehicle_number; ?></td>
		</tr>
		<tr>
			<td>Vehicle Model:</td>
			<td><?php echo $vehicle_model; ?></td>
		</tr>
		<tr>
			<td>Total km:</td>
			<td><?php echo $km_travelled; ?></td>
		</tr>
		<tr>
			<td>Cost per Kilometer:</td>
			<td><?php echo $cost_per_km; ?></td>
		</tr>
		<tr>
			<td>Total Cost:</td>
			<td><?php echo $total_cost; ?></td>
		</tr>
		<tr>
			<td>Email:</td>
			<td><?php echo $email; ?></td>
		</tr>
	</table>
 
<center><a href="index.php">HOME</a></center>
  
</a>
</h4>



