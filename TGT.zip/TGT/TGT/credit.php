<?php
session_start();
error_reporting(0);
?>
<html>
<head>
<style>
form {
  max-width: 600px;
  margin: 0 auto;
  font-family: Arial, sans-serif;
}

label {
  display: block;
  margin-bottom: 10px;
}

input[type=text],
input[type=email],
input[type=tel],
input[type=number],
input[type=password],
select {
  display: block;
  padding: 8px;
  border-radius: 5px;
  border: 1px solid #ccc;
  width: 100%;
  margin-bottom: 20px;
  font-size: 16px;
}

select {
  width: 100%;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
}

input[type=submit]:hover {
  background-color: #45a049;
}

input:invalid {
  border-color: red;
}

input:valid {
  border-color: #ccc;
}

</style>
</head>
<form method="post" action="debit_card_payment.php">
  <label for="username">Username:</label>
  <input type="text" id="username" name="username" required><br>

  <label for="phone">Phone number:</label>
  <input type="tel" id="phone" name="phone" required><br>

  <label for="email">Email address:</label>
  <input type="email" id="email" name="email" required><br>

  <label for="package">Package name:</label>
  <input type="text" id="package" name="package" required><br>

  <label for="amount">Package amount:</label>
  <input type="number" id="amount" name="amount" min="1" required><br>

  <label for="card_number">Card number:</label>
  <input type="text" id="card_number" name="card_number" required><br>

  <label for="card_expiry_month">Expiry month:</label>
  <input type="number" id="card_expiry_month" name="card_expiry_month" min="1" max="12" required>

  <label for="card_expiry_year">Expiry year:</label>
  <input type="number" id="card_expiry_year" name="card_expiry_year" min="<?php echo date('Y'); ?>" required>

  <label for="card_cvv">CVV:</label>
  <input type="password" id="card_cvv" name="card_cvv" maxlength="3" required><br>

  <input type="submit" name="submit" value="pay">

</form>

</body>
</html>