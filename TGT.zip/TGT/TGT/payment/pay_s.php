<?php
$booking_id = $_GET['booking_id'];
$payment_mode = $_POST['payment_mode'];
$payment_date = date("Y-m-d H:i:s");
$payment_amount = $_POST['payment_amount'];

$mysqli = new mysqli("localhost", "root", "", "trr");
$stmt = $mysqli->prepare("INSERT INTO payment_details (booking_id, payment_mode, payment_date, payment_amount) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isss", $booking_id, $payment_mode, $payment_date, $payment_amount);
$stmt->execute();
?>
