<form method="post" action="debit_card_payment.php">
  <label for="username">Username:</label>
  <input type="text" id="username" name="username" required><br>

  <label for="phone">Phone number:</label>
  <input type="tel" id="phone" name="phone" required><br>

  <label for="email">Email address:</label>
  <input type="email" id="email" name="email" required><br>

  <label for="package">Package name:</label>
  <input type="text" id="package" name="package" required><br>

  <label for="amount">Package amount:</label>
  <input type="number" id="amount" name="amount" min="1" required><br>

  <label for="card_number">Card number:</label>
  <input type="text" id="card_number" name="card_number" required><br>

  <label for="card_expiry_month">Expiry month:</label>
  <input type="number" id="card_expiry_month" name="card_expiry_month" min="1" max="12" required>

  <label for="card_expiry_year">Expiry year:</label>
  <input type="number" id="card_expiry_year" name="card_expiry_year" min="<?php echo date('Y'); ?>" required>

  <label for="card_cvv">CVV:</label>
  <input type="password" id="card_cvv" name="card_cvv" maxlength="3" required><br>

  <input type="submit" value="Pay">
  <button type="button" onclick="redirectToThankYouPage()">pay</button>


<script>
function redirectToThankYouPage() {
  window.location.href = "package-detailss.php";
}
</script>



</form>
