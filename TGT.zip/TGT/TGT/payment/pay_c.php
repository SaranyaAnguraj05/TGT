<?php
$booking_id = $_GET['booking_id'];

// Retrieve the booking and payment details from the database
// ...

// Display the payment confirmation details
?>
<!DOCTYPE html>
<html>
<head>
  <title>Payment Confirmation</title>
</head>
<body>
  <h1>Payment Confirmation</h1>
  <p>Thank you for your payment! Your booking ID is <?php echo $booking_id; ?>.</p>
  <h2>Booking Details</h2>
  <ul>
    <li>User Email: <?php echo $email; ?></li>
    <li>User Phone Number: <?php echo $phone_number; ?></li>
    <li>Check-in Date: <?php echo $checkin_date; ?></li>
    <li>Check-out Date: <?php echo $checkout_date; ?></li>
    
    <li>Hotel: <?php echo $hotel; ?> (<?php echo $hotel_days; ?> days)</li>
  </ul>
  <h2>Payment Details</h2>
  <ul>
    <li>Payment Mode: <?php echo $payment_mode; ?></li>
    <li>Total Amount: <?php echo $total_amount; ?></li>
    <li>Payment Status: <?php echo $payment_status; ?></li>
    <li>Transaction ID: <?php echo $transaction_id; ?></li>
    <li>Payment Date: <?php echo $payment_date; ?></li>
  </ul>
</body>
</html>
