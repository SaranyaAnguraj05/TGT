<form method="post" action="booking.php">
  <label>Email</label>
  <input type="email" name="email" required>

  <label>Phone Number</label>
  <input type="tel" name="phone_number" required>

  <label>Check-in Date</label>
  <input type="date" name="checkin_date" required>

  <label>Checkout Date</label>
  <input type="date" name="checkout_date" required>

  

  <label>Hotel Days Stayed</label>
  <input type="number" name="hotel_days">

  <label>Payment Mode</label>
  <select name="payment_mode">
    <option value="credit_card">Credit Card</option>
    <option value="debit_card">Debit Card</option>
    <option value="paypal">PayPal</option>
  </select>

  <button type="submit">Submit</button>
</form>
