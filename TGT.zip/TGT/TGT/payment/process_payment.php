<?php
$booking_id = $_POST['booking_id'];

// Retrieve the booking details from the database
// ...

// Process the payment based on the selected payment mode
$payment_mode = $_POST['payment_mode'];
switch ($payment_mode) {
  case 'credit_card':
    $card_number = $_POST['card_number'];
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];
    $cardholder_name = $_POST['cardholder_name'];

    // Process the credit card payment using the payment gateway API
    // ...
    break;
  case 'debit_card':
    $card_number = $_POST['card_number'];
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];
    $cardholder_name = $_POST['cardholder_name'];

    // Process the debit card payment using the payment gateway API
    // ...
    break;
  case 'paypal':
    $paypal_email = $_POST['paypal_email'];

    // Process the PayPal payment using the payment gateway API
    // ...
    break;
  default:
    // Invalid payment mode
    die('Invalid payment mode');
}

// Record the payment details in the database
// ...

// Redirect the user back to the confirmation page
header('Location: confirmation.php?booking_id=' . $booking_id);
exit;
?>
