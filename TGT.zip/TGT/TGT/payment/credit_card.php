<?php
$booking_id = $_GET['booking_id'];
?>

<h1>Credit Card Payment</h1>

<form action="pay_c.php" method="POST">
  <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
  <label for="card_number">Card Number:</label>
  <input type="text" name="card_number" id="card_number"><br>
  <label for="expiry_date">Expiry Date:</label>
  <input type="text" name="expiry_date" id="expiry_date"><br>
  <label for="cvv">CVV:</label>
  <input type="text" name="cvv" id="cvv"><br>
  <label for="cardholder_name">Cardholder Name:</label>
  <input type="text" name="cardholder_name" id="cardholder_name"><br>
  <input type="submit" value="Pay">
</form>
