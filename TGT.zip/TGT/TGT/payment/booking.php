<?php
$email = $_POST['email'];
$phone_number = $_POST['phone_number'];
$checkin_date = $_POST['checkin_date'];
$checkout_date = $_POST['checkout_date'];

// Calculate the number of days stayed at the hotel
$hotel_days = $_POST['hotel_days'];
$hotel_amount = $hotel_days * 1000;

// Calculate the total amount for the booking
$amount = $hotel_amount;

// Store the user information in the database
$mysqli = new mysqli("localhost", "root", "", "trr");
$stmt = $mysqli->prepare("INSERT INTO users (email, phone_number) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $phone_number);
$stmt->execute();
$user_id = $mysqli->insert_id;

// Store the booking details in the database
$stmt = $mysqli->prepare("INSERT INTO bookings (user_id, checkin_date, checkout_date,  hotel, amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssssd", $user_id, $checkin_date, $checkout_date,  $hotel_days, $amount);
$stmt->execute();
$booking_id = $mysqli->insert_id;

// Redirect the user to the payment gateway based on the selected payment mode
$payment_mode = $_POST['payment_mode'];
if ($payment_mode == "credit_card") {
  header("Location: credit_card.php?booking_id=$booking_id");
} elseif ($payment_mode == "debit_card") {
  header("Location: https://example.com/payments/debit_card.php?booking_id=$booking_id");
} elseif ($payment_mode == "paypal") {
  header("Location: https://example.com/payments/paypal.php?booking_id=$booking_id");
}
?>
