<?php
// MySQL database connection code
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Form submission code
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST["username"];
  $phone = $_POST["phone"];
  $email = $_POST["email"];
  $package = $_POST["package"];
  $amount = $_POST["amount"];
  $payment_method = $_POST["payment_method"];

  // Validation code
  $errors = array();
  if (empty($username)) {
    $errors[] = "Username is required.";
  }
  if (empty($phone)) {
    $errors[] = "Phone number is required.";
  } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
    $errors[] = "Phone number must be 10 digits.";
  }
  if (empty($email)) {
    $errors[] = "Email address is required.";
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email address.";
  }
  if (empty($package)) {
    $errors[] = "Package name is required.";
  }
  if (empty($amount)) {
    $errors[] = "Package amount is required.";
  } elseif (!is_numeric($amount)) {
    $errors[] = "Package amount must be a number.";
  }
  if (empty($payment_method)) {
    $errors[] = "Payment method is required.";
  }

  // If no validation errors, redirect to payment page
  if (empty($errors)) {
    switch ($payment_method) {
      case "credit_card":
        header("Location: credit_card_payment.php?username=$username&phone=$phone&email=$email&package=$package&amount=$amount");
        break;
      case "debit_card":
        header("Location: credit.php?username=$username&phone=$phone&email=$email&package=$package&amount=$amount");
        break;
      case "paypal":
        header("Location: paypal_payment.php?username=$username&phone=$phone&email=$email&package=$package&amount=$amount");
        break;
    }
  }
}

// HTML form code
?>
<form method="POST" action="">
  <?php if (!empty($errors)): ?>
    <ul>
      <?php foreach ($errors as $error): ?>
        <li><?= $error ?></li>
      <?php endforeach ?>
    </ul>
  <?php endif ?>
  <label for="username">Username:</label>
  <input type="text" name="username" id="username" value="<?= $_POST["username"] ?? "" ?>">
  <br>
  <label for="phone">Phone number:</label>
  <input type="text" name="phone" id="phone" value="<?= $_POST["phone"] ?? "" ?>">
  <br>
  <label for="email">Email address:</label>
  <input type="email" name="email" id="email" value="<?= $_POST["email"] ?? "" ?>">
  <br>
  <label for="package">Package name:</label>
  <input type="text" name="package" id="package" value="<?= $_POST["package"] ?? "" ?>">
  <br>
  <label for="amount">Package amount:</label>
  <input type="text" name="amount" id="amount" value="<?= $_POST["amount"] ?? ""?>">
<br>
<label for="payment_method">Payment method:</label>
<select name="payment_method" id="payment_method">
<option value="">-- Select payment method --</option>
<option value="credit_card" <?= ($_POST["payment_method"] ?? "") == "credit_card" ? "selected" : "" ?>>Credit card</option>
<option value="debit_card" <?= ($_POST["payment_method"] ?? "") == "debit_card" ? "selected" : "" ?>>Debit card</option>
<option value="paypal" <?= ($_POST["payment_method"] ?? "") == "paypal" ? "selected" : "" ?>>PayPal</option>
</select>
<br>
<button type="submit">Submit</button>

</form>
