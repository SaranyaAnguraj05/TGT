<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve payment details from database
$sql = "SELECT * FROM payment ORDER BY id DESC LIMIT 1";
$result = $conn->query($sqlif ($result->num_rows > 0) {
// Output payment details
while($row = $result->fetch_assoc()) {
echo "Payment Details:<br>";
echo "User Name: " . $row["name"] . "<br>";
echo "User Phone Number: " . $row["phone"] . "<br>";
echo "User Email: " . $row["email"] . "<br>";
echo "Package Name: " . $row["package_name"] . "<br>";

echo "Payment Amount: " . $row["amount"] . "<br>";
echo "Payment Method: " . $row["payment_method"] . "<br>";
}
} else {
echo "No payment details found.";
}

$conn->close();
?>
