<?php
// Connect to MySQL database
$conn = mysqli_connect('localhost', 'root', '', 'tms');

// Check if the form is submitted
if(isset($_POST['submit'])) {
	// Get form data
	$vehicle_number = mysqli_real_escape_string($conn, $_POST['vehicle_number']);
	$vehicle_model = mysqli_real_escape_string($conn, $_POST['vehicle_model']);
	$no_of_seats = mysqli_real_escape_string($conn, $_POST['no_of_seats']);
	$cost_per_km = mysqli_real_escape_string($conn, $_POST['cost_per_km']);
	$check_in_date = mysqli_real_escape_string($conn, $_POST['check_in_date']);
	$check_out_date = mysqli_real_escape_string($conn, $_POST['check_out_date']);
	$total_km = mysqli_real_escape_string($conn, $_POST['total_km']);
	$payment_option = mysqli_real_escape_string($conn, $_POST['payment_option']);

	// Check if the vehicle is already booked
	$check_query = "SELECT * FROM tbookings WHERE vehicle_number = '$vehicle_number' AND ((check_in_date BETWEEN '$check_in_date' AND '$check_out_date') OR (check_out_date BETWEEN '$check_in_date' AND '$check_out_date'))";
	$check_result = mysqli_query($conn, $check_query);
	if(mysqli_num_rows($check_result) > 0) {
			// Display error message if the vehicle is already booked
	echo "Sorry, this vehicle is already booked for the selected dates. Please choose another vehicle or different dates.";
} else {
	// Calculate total cost
	$total_cost = $total_km * $cost_per_km;

	// Insert booking details into database
	$insert_query = "INSERT INTO tbookings (vehicle_number, vehicle_model, no_of_seats, cost_per_km, check_in_date, check_out_date, total_km, total_cost, payment_option) VALUES ('$vehicle_number', '$vehicle_model', '$no_of_seats', '$cost_per_km', '$check_in_date', '$check_out_date', '$total_km', '$total_cost', '$payment_option')";
	mysqli_query($conn, $insert_query);

	// Display success message
	echo "Thank you for booking the vehicle. Your booking details are as follows:<br>";
	echo "Vehicle Number: " . $vehicle_number . "<br>";
	echo "Vehicle Model: " . $vehicle_model . "<br>";
	echo "No. of Seats: " . $no_of_seats . "<br>";
	echo "Cost per Kilometer: $" . $cost_per_km . "<br>";
	echo "Check-In Date: " . $check_in_date . "<br>";
	echo "Check-Out Date: " . $check_out_date . "<br>";
	echo "Total Kilometers: " . $total_km . " km<br>";
	echo "Total Cost: $" . $total_cost . "<br>";
	echo "Payment Option: " . $payment_option . "<br>";
}
}
?>