<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

			

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css" />
	<script>
		 new WOW().init();
	</script>
<script src="js/jquery-ui.js"></script>
					<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
	  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>	
<style>
form {
  display: flex;
  flex-direction: column;
  align-items: center;
}

label {
  font-weight: bold;
}

input[type="text"],
input[type="email"],
select,
input[type="date"],
input[type="submit"] {
  padding: 8px;
  margin: 5px;
  border-radius: 5px;
  border: 1px solid #ccc;
  font-size: 16px;
  width: 300px;
  box-sizing: border-box;
}

input[type="submit"] {
  background-color: #4CAF50;
  color: white;
  cursor: pointer;
  font-weight: bold;
  width: auto;
  border: none;
}

input[type="submit"]:hover {
  background-color: #45a049;
}

input[type="submit"]:active {
  background-color: #3e8e41;
  transform: translateY(1px);
}
a {
  display: inline-block; /* Make the anchor tag a block element */
  text-decoration: none; /* Remove underline from anchor text */
  text-align: center; /* Align anchor text to center */
}

button {
  padding: 10px 20px; /* Add padding to the button */
  background-color: #4CAF50; /* Set background color */
  color: white; /* Set text color */
  border: none; /* Remove button border */
  cursor: pointer; /* Change cursor to pointer on hover */
  border-radius: 5px; /* Add rounded corners to the button */
  transition: background-color 0.3s ease; /* Add transition effect to background color */
}

button:hover {
  background-color: #3e8e41; /* Change background color on hover */
}


</style>


</head>



	<center><h1>Hotel Room Booking Form</h1></center>
	<form action="booking.php" method="post">
		<label for="name">Name:</label>
		<input type="text" id="name" name="name" required>
		<br><br>
		
		<label for="email">Email:</label>
		<input type="email" id="email" name="email" required>
		<br><br>
		
		<label for="hotel">Hotel:</label>
		<select id="hotel" name="hotel" required>
			<option value="">Select Hotel</option>
			<option value="Hotel 1">Ramyas</option>
			<option value="Hotel 2">Grand Inn</option>
			<option value="Hotel 3">Courtyard by Marriot</option>
		</select>
		<br><br>
		
		<label for="room_number">Room Number:</label>
		<select id="room_number" name="room_number" required>
			<option value="">Select Room Number</option>
			<option value="101">suit room (101-150)</option>
			<option value="102">single stay room(151-200)</option>
			<option value="103">double stay room(201-250)</option>
			<option value="104">normal room(251-300)</option>
		</select>
		<br><br>
		<div class="ban-bottom">
    <div class="bnr-right">
		<label for="checkin_date">Check-in Date:</label>
		<input class="date" id="datepicker" name="check_in_date" id="check_in_date" style="" required><br><br>
		<br><br>

		<label for="checkout_date">Check-out Date:</label>
		<input class="date" id="datepicker1" name="check_out_date" id="check_out_date" style="" required><br><br>
		</div></div>
		<br><br>
		<br><br>
		<input type="submit" value="Book Room">
	</form>

<a href="index.php">
  <button>home</button>
</a>

</html>