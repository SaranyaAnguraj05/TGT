
<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title> Hotel Room</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
</head>
<body>
<?php include('includes/header.php');?>
<!--- banner ---->
<div class="banner-3">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">  Hotel Room Booking</h1>
	</div>
</div>
<!--- /banner ---->
<!--- rooms ---->
<div class="rooms">
	<div class="container">
		
		<div class="room-bottom">



<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$hotel = $_POST['hotel'];
	$room_number = $_POST['room_number'];
	$checkin_date = $_POST['checkin_date'];
	$checkout_date = $_POST['checkout_date'];
	$payment_option = $_POST['payment_option'];

	// Connect to the database
	$conn = mysqli_connect('localhost', 'root', '', 'tms');

	// Check if the room is already booked in the specified dates
	$query = "SELECT * FROM bookings WHERE room_number='$room_number' AND ((checkin_date BETWEEN '$checkin_date' AND '$checkout_date') OR (checkout_date BETWEEN '$checkin_date' AND '$checkout_date'))";
	$result = mysqli_query($conn, $query);
	if (mysqli_num_rows($result) > 0) {
		// Room is already booked, display error message
		echo "Error: Room is already booked in the specified dates.";
	} else {
		// Room is available, insert the booking into the database
		$query = "INSERT INTO bookings (name, email, hotel, room_number, checkin_date, checkout_date, payment_option) VALUES ('$name', '$email', '$hotel', '$room_number', '$checkin_date', '$checkout_date', '$payment_option')";
		mysqli_query($conn, $query); 
                $link = "hcredit.php";

		
                
	}

	// Close the database connection
	mysqli_close($conn);
}

?>
<a href="<?php echo $link; ?>">PAYMENT</a>
<!--- /selectroom ---->
<<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>