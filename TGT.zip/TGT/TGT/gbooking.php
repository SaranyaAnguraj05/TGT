<?php
// Connect to MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form data
$user_email = $_POST['user_email'];
$guide_id = $_POST['guide_id'];
$guide_destination = $_POST['guide_destination'];
$checkin_date = $_POST['checkin_date'];
$checkout_date = $_POST['checkout_date'];

// Check if guide is available for booking
$sql = "SELECT * FROM guides WHERE id = '$guide_id' AND destination = '$guide_destination'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $guide_name = $row['name'];
    $guide_phone = $row['phone'];
    $guide_email = $row['email'];

    // Check if guide is available for booking dates
    $sql = "SELECT * FROM bookings WHERE guide_id = '$guide_id' AND ((checkin_date <= '$checkin_date' AND checkout_date >= '$checkin_date') OR (checkin_date <= '$checkout_date' AND checkout_date >= '$checkout_date') OR ('$checkin_date' <= checkin_date AND '$checkout_date' >= checkout_date))";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 0) {
        // Book guide
        $sql = "INSERT INTO bookings (user_email, guide_id, guide_name, guide_phone, guide_email, guide_destination, checkin_date, checkout_date) VALUES ('$user_email', '$guide_id', '$guide_name', '$guide_phone', '$guide_email', '$guide_destination', '$checkin_date', '$checkout_date')";
        if (mysqli_query($conn, $sql)) {
            echo "Guide booked successfully!";
        } else {
            echo "Error booking guide: " . mysqli_error($conn);
        }
    } else {
        echo "Guide is already booked for the specified dates.";
    }
} else {
    echo "Guide not found.";
}

// Close MySQL connection
mysqli_close($conn);
?>
