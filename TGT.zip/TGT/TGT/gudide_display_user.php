<?php

session_start();
error_reporting(0);



?>
	




<html>
<head>
<style>
<h1 {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
}

form {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

label {
  font-size: 18px;
  margin-right: 10px;
}

input[type="text"] {
  padding: 5px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

button[type="submit"] {
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: none;
  background-color: #4CAF50;
  color: #fff;
  cursor: pointer;
}

button[type="submit"]:hover {
  background-color: #3e8e41;
}

</style>
</head>
	<h1>My Bookings</h1>
	<form action="mybookings.php" method="GET">
		<label for="email">Email:</label>
		<input type="text" name="email" required>
		<button type="submit">Search</button>
	</form>

	<?php
	// Check if email parameter is provided
	if (isset($_GET['email'])) {
		$email = $_GET['email'];

		// Connect to the database
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "tms";

		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		}

		// Query the bookings table and join it with the guides table
		$sql = "SELECT gbookings.booking_id, gbookings.user_email, guides.guide_name, gbookings.checkin_date, gbookings.checkout_date
		        FROM gbookings
		        INNER JOIN guides
		        ON gbookings.guide_id = guides.guide_id
		        WHERE gbookings.user_email = '$email'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
		    // Output data of each row in a table
		    echo "<h2>Bookings for $email</h2>";
		    echo "<table><tr><th>Booking ID</th><th>User Email</th><th>Guide Name</th><th>Checkin Date</th><th>Checkout Date</th></tr>";
		    while($row = $result->fetch_assoc()) {
		        echo "<tr><td>" . $row["booking_id"]. "</td><td>" . $row["user_email"]. "</td><td>" . $row["guide_name"]. "</td><td>" . $row["checkin_date"]. "</td><td>" . $row["checkout_date"]. "</td></tr>";
		    }
		    echo "</table>";
		} else {
		    echo "<p>No bookings found for $email.</p>";
		}

		$conn->close();
	}
	?>



</body>
</html>










