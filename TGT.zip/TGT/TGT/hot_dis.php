<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>


<html>
<head>
	<title>View Booking Details</title>
<style>
form {
  max-width: 500px;
  margin: 0 auto;
}

h1 {
  text-align: center;
  font-size: 2rem;
  margin-top: 50px;
}

label {
  display: block;
  margin-bottom: 10px;
}

input[type="email"] {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 1rem;
  width: 100%;
  margin-bottom: 20px;
}

button[type="submit"] {
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

button[type="submit"]:hover {
  background-color: #0069d9;
}
a {
  display: inline-block; /* Make the anchor tag a block element */
  text-decoration: none; /* Remove underline from anchor text */
  text-align: center; /* Align anchor text to center */
}

button {
  padding: 10px 20px; /* Add padding to the button */
  background-color: #4CAF50; /* Set background color */
  color: white; /* Set text color */
  border: none; /* Remove button border */
  cursor: pointer; /* Change cursor to pointer on hover */
  border-radius: 5px; /* Add rounded corners to the button */
  transition: background-color 0.3s ease; /* Add transition effect to background color */
}

button:hover {
  background-color: #3e8e41; /* Change background color on hover */
}

</style>

</head>
<body>
	<h1>View Booking Details</h1>
	<form method="POST" action="booking-details.php">
		<label for="email">Email:</label>
		<input type="email" id="email" name="email" required>
		<button type="submit">View Details</button>
	</form>
<a href="index.php">
  <button>home</button>
</a>

</body>
</html>
