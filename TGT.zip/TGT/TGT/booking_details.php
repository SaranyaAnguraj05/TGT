<?php
// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "tms");

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get the booking ID from the URL parameter
$id = $_GET['id'];

// Retrieve the booking details from the database
$sql = "SELECT * FROM tbookings WHERE id = '$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // Output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    $vehicle_id = $row["vehicle_id"];
    $vehicle_number = $row["vehicle_number"];
    $vehicle_model = $row["vehicle_model"];
    $no_of_seats = $row["no_of_seats"];
    $cost_per_km = $row["cost_per_km"];
    $total_cost = $row["total_cost"];
    
  }
} else {
  echo "Booking not found.";
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Booking Details</title>
</head>
<body>
  <h1>Booking Details</h1>
  <p><strong>ID:</strong> <?php echo $id; ?></p>
  <p><strong>Vehicle ID:</strong> <?php echo $vehicle_id; ?></p>
  <p><strong>Vehicle Number:</strong> <?php echo $vehicle_number; ?></p>
  <p><strong>Vehicle Model:</strong> <?php echo $vehicle_model; ?></p>
  <p><strong>No. of Seats:</strong> <?php echo $no_of_seats; ?></p>
  <p><strong>Cost per km:</strong> <?php echo $cost_per_km; ?></p>
  <p><strong>Total Cost:</strong> <?php echo $total_cost; ?></p>
  
</body>
</html>
