<?php

session_start();
error_reporting(0);
include('includes/config.php');


?>
	


<head>
<title>TRAVEL GUIDE PORTAL FOR TRICHIRAPALLI</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
<!-- top-header -->
<div class="top-header">
<?php include('includes/header.php');?>
<div class="banner-1 ">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">TRAVEL GUIDE PORTAL FOR TRICHIRAPALLI</h1>
	</div>
</div>
<!--- /banner-1 ----><!--- privacy ---->
<div class="privacy">
	<div class="container">

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";

// Get the form data

$vehicle_id = $_POST['vehicle_id'];

$check_in_date = $_POST['check_in_date'];
$check_out_date = $_POST['check_out_date'];
$km_travelled = $_POST['km_travelled'];
$email = $_POST['email'];

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the vehicle details from the database
$sql = "SELECT id, vehicle_number, vehicle_model,  cost_per_km FROM vehicles WHERE id = '$vehicle_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $vehicle_number = $row['vehicle_number'];
  $vehicle_model = $row['vehicle_model'];
  $cost_per_km = $row['cost_per_km'];
  $vehicle_no_of_seats = $row['no_of_seats'];
} else {
  die("Invalid vehicle ID.");
}

// Calculate the cost based on the number of kilometers travelled and the cost per km of the vehicle
$total_cost = $km_travelled * $cost_per_km;

// Check if the vehicle is available for the selected dates
$sql = "SELECT id FROM tbookings WHERE vehicle_id = '$vehicle_id' AND ((check_in_date <= '$check_in_date' AND check_out_date >= '$check_in_date') OR (check_in_date <= '$check_out_date' AND check_out_date >= '$check_out_date'))";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  die("Vehicle is already booked for the selected dates.");
}

// Add the booking to the database
$sql = "INSERT INTO tbookings (vehicle_id,  check_in_date, check_out_date, km_travelled, total_cost,email) VALUES ('$vehicle_id',  '$check_in_date', '$check_out_date', '$km_travelled', '$total_cost','$email')";
if ($conn->query($sql) === TRUE) {
  // Store the booking details in session variables
  session_start();
 
 
 $_SESSION['booking_id'] = $conn->insert_id;
  $_SESSION['vehicle_id'] = $vehicle_id;
  $_SESSION['vehicle_number'] = $vehicle_number;
  $_SESSION['vehicle_model'] = $vehicle_model;
 $_SESSION['km_travelled'] = $km_travelled;
  $_SESSION['cost_per_km'] = $cost_per_km;
  $_SESSION['total_cost'] = $total_cost;
 $_SESSION['email'] = $email;

  // Redirect to the booking confirmation page
  $link = "booking_confirmation.php";

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
<a href="<?php echo $link; ?>">VIEW DETAILS</a>

<!--- /privacy ---->
<!--- footer-top ---->
<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>


