<?php

session_start();
error_reporting(0);



?>
	


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css" />
	<script>
		 new WOW().init();
	</script>
<script src="js/jquery-ui.js"></script>
					<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
	  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>		

<style>
form {
   width: 50%;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;
  max-width: 600px;
}

label {
  font-weight: bold;
  margin-right: 10px;
  align:center;
}

input[type="email"],
input[type="date"],
select {
  padding: 5px;
  margin-bottom: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
  align:center;
}

input[type="submit"] {
  padding: 10px 20px;
  border-radius: 5px;
  border: none;
  background-color: #4CAF50;
  color: white;
  font-size: 16px;
  cursor: pointer;
  align:center;
}

input[type="submit"]:hover {
  background-color: #3e8e41;
}

a {
  display: inline-block; /* Make the anchor tag a block element */
  text-decoration: none; /* Remove underline from anchor text */
  text-align: center; /* Align anchor text to center */
}

button {
  padding: 10px 20px; /* Add padding to the button */
  background-color: #4CAF50; /* Set background color */
  color: white; /* Set text color */
  border: none; /* Remove button border */
  cursor: pointer; /* Change cursor to pointer on hover */
  border-radius: 5px; /* Add rounded corners to the button */
  transition: background-color 0.3s ease; /* Add transition effect to background color */
}

button:hover {
  background-color: #3e8e41; /* Change background color on hover */
}
</style>
</head>
<center><h1>Travel Guide Booking Form</h1></center>
	<form method="post" action="booked_details.php">
		<label for="user_email">User Email:</label>
		<input type="email" id="user_email" name="user_email"><br>

		<label for="guide_id">Guide:</label>
		<select id="guide_id" name="guide_id">
			<?php
			// Retrieve the list of available guides from the database
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "tms";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}

			// Retrieve the list of available guides
			$sql = "SELECT * FROM guides";
			$result = $conn->query($sql);

			// Display the list of guides in a dropdown menu
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo "<option value='" . $row["guide_id"] . "'>" . $row["guide_name"] . "</option>";
				}
			} else {
				echo "No guides available";
			}

			$conn->close();
			?>
		</select>
<br>
<br>
<div class="ban-bottom">
    <div class="bnr-right">
		<label for="checkin_date">Check-in Date:</label>

		<input class="date" id="datepicker" name="checkin_date" id="check_in_date" style="" required><br><br>

		<label for="checkout_date">Check-out Date:</label>
		<input class="date" id="datepicker1" id="checkout_date" name="checkout_date"><br>
</div>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
</div>
		<input type="submit" value="Submit">


	</form>
            <a href="index.php">
  <button>home</button>

</html>
