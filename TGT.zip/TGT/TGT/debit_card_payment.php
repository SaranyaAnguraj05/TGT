
<?php
// MySQL database connection code
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Retrieve data from POST parameters
if(!isset($_POST['submit'])){
$username = $_POST["username"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$package = $_POST["package"];
$amount = $_POST["amount"];
$card_number = $_POST["card_number"];
$card_expiry_month = $_POST["card_expiry_month"];
$card_expiry_year = $_POST["card_expiry_year"];
$card_cvv = $_POST["card_cvv"];

// Validate input
if (empty($username) || empty($phone) || empty($email) || empty($package) || empty($amount) || empty($card_number) || empty($card_expiry_month) || empty($card_expiry_year) || empty($card_cvv)) {
  die("Please fill in all fields");
}

if (!is_numeric($phone) || strlen($phone) != 10) {
  die("Please enter a valid phone number");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  die("Please enter a valid email address");
}

if (!is_numeric($amount) || $amount <= 0) {
  die("Please enter a valid amount");
}

if (!is_numeric($card_number) || strlen($card_number) != 16) {
  die("Please enter a valid card number");
}

if (!is_numeric($card_expiry_month) || $card_expiry_month < 1 || $card_expiry_month > 12) {
  die("Please enter a valid expiry month");
}

if (!is_numeric($card_expiry_year) || strlen($card_expiry_year) != 4 || $card_expiry_year < date("Y")) {
  die("Please enter a valid expiry year");
}

if (!is_numeric($card_cvv) || strlen($card_cvv) != 3) {
  die("Please enter a valid CVV");
}

// Insert data into MySQL database
$sql="INSERT INTO payments (username, phone, email, package, amount, payment_method) VALUES ('$username', '$phone', '$email', '$package', '$amount', 'Credit card')";

mysqli_query($conn, $sql);

echo'payment compleeted successfully';

}
?>
<a href="tour-history">click here to view  your booking details</a>

