<div class="copyrights">
	 <p>© 2023  All Rights Reserved |  <a href="#"></a> </p>
</div>	
