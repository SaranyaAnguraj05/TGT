<?php

session_start();
error_reporting(0);
include('includes/config.php');


?>
	


<head>
<title>TRAVEL GUIDE PORTAL FOR TRICHIRAPALLI</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
<!-- top-header -->
<div class="top-header">
<?php include('includes/header.php');?>
<div class="banner-1 ">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">TRAVEL GUIDE PORTAL FOR TRICHIRAPALLI</h1>
	</div>
</div>
<!--- /banner-1 ----><!--- privacy ---->
<div class="privacy">
	<div class="container">





<?php
// Retrieve the booking details from the form
$user_email = $_POST["user_email"];
$guide_id = $_POST["guide_id"];
$checkin_date = $_POST["checkin_date"];
$checkout_date = $_POST["checkout_date"];

// Check if the selected guide is available during the specified dates
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

// Check if the selected guide is available during the specified dates
$sql = "SELECT * FROM gbookings WHERE guide_id='$guide_id' AND ((checkin_date BETWEEN '$checkin_date' AND '$checkout_date') OR (checkout_date BETWEEN '$checkin_date' AND '$checkout_date'))";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
// If the guide is already booked during the specified dates, display an error message
echo "The selected guide is not available during the specified dates.";
} else {
// If the guide is available during the specified dates, insert the booking details into the "bookings" table
$sql = "INSERT INTO gbookings (user_email, guide_id, checkin_date, checkout_date) VALUES ('$user_email', '$guide_id', '$checkin_date', '$checkout_date')";
if ($conn->query($sql) === TRUE) {
echo "Booking successful!";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
}

$conn->close();
?>

<!--- /privacy ---->
<!--- footer-top ---->
<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>


