<?php
// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "tms");

// Retrieve the booked details from the database
$query = "SELECT * FROM gbookings b JOIN guides g ON b.guide_id = g.id WHERE user_email = '{$_GET['email']}'";
$result = mysqli_query($conn, $query);

// Display the booked details in a table format
if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    echo "<tr><th>Guide Name</th><th>Guide Phone</th><th>Destination</th><th>Checkin Date</th><th>Checkout Date</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['phone_number'] . "</td>";
        echo "<td>" . $row['destination'] . "</td>";
        echo "<td>" . $row['checkin_date'] . "</td>";
        echo "<td>" . $row['checkout_date'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
   echo "no bookings";
}

// Close the database connection
mysqli_close($conn);
?>




