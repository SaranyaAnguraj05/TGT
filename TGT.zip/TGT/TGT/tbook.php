<!DOCTYPE html>
<html>
<head>
	<title>Vehicle Booking Form</title>
</head>
<body>
	<h2>Vehicle Booking Form</h2>
	<form method="post" action="">
		<label for="email">Email:</label>
		<input type="email" name="email" id="email" required><br><br>

		<label for="vehicle_no">Vehicle Number:</label>
		<select name="vehicle_no" id="vehicle_no" required>
			<option value="">Select Vehicle Number</option>
			<?php
			// connect to the database
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "tms";
			$conn = new mysqli($servername, $username, $password, $dbname);

			// get the list of vehicle numbers from the database
			$sql = "SELECT vehicle_no FROM vehicles";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo '<option value="'.$row['vehicle_no'].'">'.$row['vehicle_no'].'</option>';
				}
			}

			// close the database connection
			$conn->close();
			?>
		</select><br><br>

		<label for="vehicle_model">Vehicle Model:</label>
		<select name="vehicle_model" id="vehicle_model" required>
			<option value="">Select Vehicle Model</option>
			<?php
			// connect to the database
			$servername = "localhost";
			$username = "username";
			$password = "password";
			$dbname = "database_name";
			$conn = new mysqli($servername, $username, $password, $dbname);

			// get the list of vehicle models from the database
			$sql = "SELECT vehicle_model FROM vehicles";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo '<option value="'.$row['vehicle_model'].'">'.$row['vehicle_model'].'</option>';
				}
			}

			// close the database connection
			$conn->close();
			?>
		</select><br><br>

		<label for="seats">Number of Seats:</label>
		<input type="number" name="seats" id="seats" required><br><br>

		<label for="cost_per_km">Cost per Kilometer:</label>
		<?php
		// connect to the database
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "tms";
		$conn = new mysqli($servername, $username, $password, $dbname);

		// get the cost per kilometer from the database based on the selected vehicle model
		if(isset($_POST['vehicle_model'])) {
			$vehicle_model = $_POST['vehicle_model'];
			$sql = "SELECT cost_per_km FROM vehicless WHERE vehicle_model='$vehicle_model'";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				$row = $result->fetch_assoc();
				echo '<input type="number" name="cost_per_km" id="cost_per_km" value="'.$row['cost_per_km'].'" required>';
			}
		} else {
		echo '<input type="number" name="cost_per_km" id="cost_per_km" required>';
	}

	// close the database connection
	$conn->close();
	?><br><br>

	<label for="checkin_date">Check In Date:</label>
	<input type="date" name="checkin_date" id="checkin_date" required><br><br>

	<label for="checkout_date">Check Out Date:</label>
	<input type="date" name="checkout_date" id="checkout_date" required><br><br>

	<label for="kilometers">Kilometers:</label>
	<input type="number" name="kilometers" id="kilometers" onchange="calculateAmount()" required><br><br>

	<label for="total_amount">Total Amount:</label>
	<input type="number" name="total_amount" id="total_amount" readonly><br><br>

	<label for="payment_option">Payment Option:</label>
	<select name="payment_option" id="payment_option" required>
		<option value="">Select Payment Option</option>
		<option value="cash">Cash</option>
		<option value="card">Card</option>
		<option value="online">Online</option>
	</select><br><br>

	<input type="submit" name="submit" value="Book">
</form>

<script>
	function calculateAmount() {
		var kilometers = document.getElementById('kilometers').value;
		var cost_per_km = document.getElementById('cost_per_km').value;
		var total_amount = kilometers * cost_per_km;
		document.getElementById('total_amount').value = total_amount;
	}
</script>

<?php
if(isset($_POST['submit'])) {
	// get the form data
	$email = $_POST['email'];
	$vehicle_no = $_POST['vehicle_no'];
	$vehicle_model = $_POST['vehicle_model'];
	$seats = $_POST['seats'];
	$cost_per_km = $_POST['cost_per_km'];
	$checkin_date = $_POST['checkin_date'];
	$checkout_date = $_POST['checkout_date'];
	$kilometers = $_POST['kilometers'];
	$total_amount = $_POST['total_amount'];
	$payment_option = $_POST['payment_option'];

	// connect to the database
	$servername = "localhost";
	$username = "username";
	$password = "password";
	$dbname = "database_name";
	$conn = new mysqli($servername, $username, $password, $dbname);

	// check if the vehicle is available for booking
	$sql = "SELECT * FROM ttbookings WHERE vehicle_no='$vehicle_no' AND ((checkin_date<='$checkin_date' AND checkout_date>='$checkin_date') OR (checkin_date<'$checkout_date' AND checkout_date>='$checkout_date') OR (checkin_date>='$checkin_date' AND checkout_date<'$checkout_date'))";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		echo "The vehicle is already booked for the selected dates.";
	} else {
		// insert the booking details into the database
		$sql = "INSERT INTO ttbookings (email, vehicle_no, vehicle_model, seats, cost_per_km, checkin_date, checkout_date, kilometers, total_amount, payment_option) VALUES ('$email', '$vehicle_no', '$vehicle_model', '$seats', '$cost_per_km', '$checkin_date', $checkout_date', '$kilometers', '$total_amount', '$payment_option')";
		if ($conn->query($sql) === TRUE) {
			echo "Booking successful!";
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}

	// close the database connection
	$conn->close();
}
?>
</body>
</html>

