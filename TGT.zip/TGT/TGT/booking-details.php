<?php
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $email = $_GET['email'];

    // Connect to the database
   
    $conn = mysqli_connect('localhost', 'root', '', 'tms');

    // Execute the SQL SELECT query to fetch the booking details for the specified email
    $query = "SELECT * FROM bookings WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    // Check if any bookings were found
    if (mysqli_num_rows($result) > 0) {
        // Display the booking details
        echo "<h1>Booking details for $email</h1>";
        echo "<table>";
        echo "<tr><th>Booking ID</th><th>Name</th><th>Email</th><th>Hotel</th><th>Room Number</th><th>Check-in Date</th><th>Check-out Date</th><th>Payment Option</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>{$row['booking_id']}</td><td>{$row['name']}</td><td>{$row['email']}</td><td>{$row['hotel']}</td><td>{$row['room_number']}</td><td>{$row['checkin_date']}</td><td>{$row['checkout_date']}</td><td>{$row['payment_option']}</td></tr>";
        }
        echo "</table>";
    } else {
        // No bookings were found for the specified email
        echo "<p>No bookings found for $email.</p>";
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
