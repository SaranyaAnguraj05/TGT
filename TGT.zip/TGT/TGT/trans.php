<?php
session_start();
error_reporting(0);

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tms";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the list of vehicles from the database
$sql = "SELECT id, vehicle_number, vehicle_model, cost_per_km FROM vehicles";
$result = $conn->query($sql);
$vehicles = array();
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $vehicles[] = $row;
  }
}
$conn->close();
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css" />
	<script>
		 new WOW().init();
	</script>
<script src="js/jquery-ui.js"></script>
					<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
	  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>		
<style>
form {
  width:50%;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;
  max-width: 600px;
}

label {
  display: inline-block;
  width: 200px;
  margin-bottom: 10px;
}

input[type="number"],
input[type="date"],
input[type="email"],
input[type="submit"] {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  margin-bottom: 10px;
  width: 100%;
}

input[type="submit"] {
  background-color: #4CAF50;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s ease-in-out;
}

input[type="submit"]:hover {
  background-color: #45a049;
}

a {
  display: inline-block; /* Make the anchor tag a block element */
  text-decoration: none; /* Remove underline from anchor text */
  text-align: center; /* Align anchor text to center */
}

button {
  padding: 10px 20px; /* Add padding to the button */
  background-color: #4CAF50; /* Set background color */
  color: white; /* Set text color */
  border: none; /* Remove button border */
  cursor: pointer; /* Change cursor to pointer on hover */
  border-radius: 5px; /* Add rounded corners to the button */
  transition: background-color 0.3s ease; /* Add transition effect to background color */
}

button:hover {
  background-color: #3e8e41; /* Change background color on hover */
}



</style>
</head>		

  <center><h1>Vehicle Booking Form</h1><h4> note:tata nexa(5) the bracket(5) represents no of seats</h4></center>
<body>  
<form action="booking_submit.php" method="post" align="center">
    <label for="vehicle_id">Vehicle:</label>
    <select name="vehicle_id" id="vehicle_id">
      <?php foreach ($vehicles as $vehicle): ?>
        <option value="<?php echo $vehicle['id']; ?>"><?php echo $vehicle['vehicle_number'] . " - " . $vehicle['vehicle_model']; ?></option>
      <?php endforeach; ?>
    </select><br><br>
   <div class="ban-bottom">
    <div class="bnr-right">
    <label for="check_in_date">Check-in Date:</label>
    <input class="date" id="datepicker" name="check_in_date" id="check_in_date" style="" required><br><br>
    </div>
<div class="bnr-right">
    <label for="check_out_date">Check-out Date:</label>
    <input class="date" id="datepicker1" name="check_out_date" id="check_out_date" required><br><br>
</div>
</div>
    <label for="km_travelled">Kilometers Travelled:</label>
    <input type="number" name="km_travelled" id="km_travelled" min="1" required><br><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>
<br>
    <input type="submit" value="book vehicle">
 
</form>

<a href="index.php">
  <button>home</button>
</a>

</body>
</html>

