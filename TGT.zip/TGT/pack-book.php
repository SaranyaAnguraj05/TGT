<!DOCTYPE html>
<html>
<head>
	<title>Booking Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h2>Book a Package</h2>
	<form method="post" action="payment.php">
		<label>Email:</label>
		<input type="email" name="email" required>
		<label>Phone Number:</label>
		<input type="tel" name="phone" required>
		<label>Check-In Date:</label>
		<input type="date" name="checkin" required>
		<label>Check-Out Date:</label>
		<input type="date" name="checkout" required>
		<label>Number of Persons:</label>
		<input type="number" name="persons" min="1" max="10" required>
		<button type="submit" name="submit">Book Package</button>
	</form>
</body>
</html>
<?php
if(isset($_POST['submit'])){
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$checkin = $_POST['checkin'];
	$checkout = $_POST['checkout'];
	$persons = $_POST['persons'];
	
	$guide_amount = 1000;
	$transport_amount = 3000;
	$hotel_amount = $persons * 800;
	
	$total_amount = $guide_amount + $transport_amount + $hotel_amount;
	
	if($total_amount > 0){
		header('Location: payment.php?email='.$email.'&phone='.$phone.'&checkin='.$checkin.'&checkout='.$checkout.'&persons='.$persons.'&total='.$total_amount);
		exit();
	}
	else{
		echo "Invalid package details!";
	}
}
?>
