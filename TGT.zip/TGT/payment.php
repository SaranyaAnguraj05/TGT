<!DOCTYPE html>
<html>
<head>
	<title>Payment Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h2>Payment Details</h2>
	<p>Total Package Amount: <?php echo $_GET['total_amount']; ?></p>
	<form method="post" action="confirm.php">
		<label>Card Number:</label>
		<input type="text" name="card_number" required>
		<label>Expiry Date:</label>
		<input type="month" name="expiry_date" required>
		<label>CVC:</label>
		<input type="password" name="cvc" required>
		<button type="submit" name="submit">Make Payment</button>
		<input type="hidden" name="email" value="<?php echo $_GET['email']; ?>">
		<input type="hidden" name="phone" value="<?php echo $_GET['phone']; ?>">
		<input type="hidden" name="checkin" value="<?php echo $_GET['checkin']; ?>">
		<input type="hidden" name="checkout" value="<?php echo $_GET['checkout']; ?>">
		<input type="hidden" name="persons" value="<?php echo $_GET['persons']; ?>">
		<input type="hidden" name="total" value="<?php echo $_GET["total"];?>">
</body>
</html>
<?php
if(isset($_POST['submit'])){
	$card_number = $_POST['card_number'];
	$expiry_date = $_POST['expiry_date'];
	$cvc = $_POST['cvc'];
	
	if($card_number && $expiry_date && $cvc){
		header('Location: confirm.php?email='.$_POST['email'].'&phone='.$_POST['phone'].'&checkin='.$_POST['checkin'].'&checkout='.$_POST['checkout'].'&persons='.$_POST['persons'].'&total='.$_POST['total']);
		exit();
	}
	else{
		echo "Invalid payment details!";
	}
}
?>




