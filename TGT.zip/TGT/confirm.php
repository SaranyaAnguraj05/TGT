<!DOCTYPE html>
<html>
<head>
	<title>Confirmation Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h2>Booking Confirmation</h2>
	<p>Email: <?php echo $_GET['email']; ?></p>
	<p>Phone Number: <?php echo $_GET['phone']; ?></p>
	<p>Check-In Date: <?php echo $_GET['checkin']; ?></p>
	<p>Check-Out Date: <?php echo $_GET['checkout']; ?></p>
	<p>Number of Persons: <?php echo $_GET['persons']; ?></p>
	<p>Total Package Amount: <?php echo $_GET['total']; ?></p>
	<?php
	// Connect to database
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "guides";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection failed: ".mysqli_connect_error());
	}
	
	// Check if guide is already assigned
	$sql = "SELECT * FROM guides WHERE status='available' LIMIT 1";
	$result = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($result) > 0){
		$row = mysqli_fetch_assoc($result);
		
		// Assign guide
		$sql = "UPDATE guides SET status='assigned', email='".$_GET['email']."' WHERE id=".$row['id'];
		mysqli_query($conn, $sql);
		
		// Display guide details
		echo "<h3>Guide Details</h3>";
		echo "<p>Name: ".$row['name']."</p>";
		echo "<p>Email: ".$row['email']."</p>";
		echo "<p>Phone Number: ".$row['phone']."</p>";
	}
	else{
		echo "No guides available at the moment. Please try again later.";
	}
	
	mysqli_close($conn);
	?>
</body>
</html>
